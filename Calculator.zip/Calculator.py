import tkinter as tk
import tkinter.ttk as ttk
window = tk.Tk()
window.title('Calculator')
window.geometry('500x500')
window.configure(bg='lightblue')

e = ttk.Entry(width = 56)
e.place(x=0, y=0)

def click(num):
    result = e.get()
    e.delete(0, tk.END)
    e.insert(0,str(result)+str(num))

b1=ttk.Button(text='1', width=12, command = lambda: click(1))
b1.place(x=10, y=60)

b2=ttk.Button(text='2', width=12, command = lambda: click(2))
b2.place(x=80, y=60)
b3=ttk.Button(text='3', width=12, command = lambda: click(3))
b3.place(x=150, y=60)

b4=ttk.Button(text='4', width=12,  command = lambda: click(4))
b4.place(x=10, y=120)

b5=ttk.Button(text='5', width=12, command = lambda: click(5))
b5.place(x=80, y=120)

b6=ttk.Button(text='6', width=12, command = lambda: click(6))
b6.place(x=150, y=120)

b7=ttk.Button(text='7', width=12, command = lambda: click(7))
b7.place(x=10, y=180)

b8=ttk.Button(text='8', width=12, command = lambda: click(8))
b8.place(x=80, y=180)
b9=ttk.Button( text='9', width=12, command = lambda: click(9))
b9.place(x=150, y=180)

b10=ttk.Button(text='0', width=12, command = lambda: click(0))
b10.place(x=10, y=240)

def add():
    n1 = e.get()
    global math
    math='addition'
    global i
    i=eval(n1)
    e.delete(0, tk.END)

b11=ttk.Button(text='+',width=12, command = add)
b11.place(x=80, y=240)

def sub():
    n1 = e.get()
    global math
    math='subtraction'
    global i
    i=eval(n1)
    e.delete(0, tk.END)

b12=ttk.Button(text='-',width=12, command=sub)
b12.place(x=150, y=240)
def mul():
    n1 = e.get()
    global math
    math='multiplication'
    global i
    i=eval(n1)
    e.delete(0, tk.END)
b13=ttk.Button(text='*',width=12, command = mul)
b13.place(x=10,y=300)
def div():
    n1 = e.get()
    global math
    math='division'
    global i
    i=eval(n1)
    e.delete(0, tk.END)

b14=ttk.Button(text='/',width=12, command = div)
b14.place(x=80, y=300)

def equal():
    n2 = e.get()
    e.delete(0, tk.END)
    if math=='addition':
        e.insert(0, i + eval(n2))
    elif math=='subtraction':
        e.insert(0, i - eval(n2))
    elif math=='multiplication':
        e.insert(0, i * eval(n2))
    elif math=='division':
        e.insert(0, i / eval(n2))


b15=ttk.Button(text='=',width=12, command=equal)
b15.place(x=150, y=300)

def clear():
    e.delete(0, tk.END)


b16=ttk.Button(text='clear',width=12, command = clear)
b16.place(x=10,y=350)
window.mainloop()
